Read me
========

If you dont know the given file font/format/encoding first click "Detect Font Type"; Then start the conversion process.

Thank you
